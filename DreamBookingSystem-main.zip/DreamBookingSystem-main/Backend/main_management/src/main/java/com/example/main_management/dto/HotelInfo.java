package com.example.main_management.dto;

public class HotelInfo {
}

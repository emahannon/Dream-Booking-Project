package com.example.main_management.entity.enams;

public enum RoomType {
    SINGLE,
    DOUBLE,
    SUITE
}

class Task {
    performAs(user) {
        throw new Error('performAs method must be implemented');
    }
}

export default Task;
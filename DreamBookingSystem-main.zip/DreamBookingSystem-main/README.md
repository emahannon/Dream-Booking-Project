# :briefcase: :airplane_departure: Dream Booking System

This system will implement simple and easy bookings for flights and hotels.


# Installation/Usage 
## Installation Instructions

- Installation/build instructions will be written here

# Project Structure
- Backend - contains all backend code
- Frontend - contains all React frontend code
